<?php
	mysqli_close($link);
?>